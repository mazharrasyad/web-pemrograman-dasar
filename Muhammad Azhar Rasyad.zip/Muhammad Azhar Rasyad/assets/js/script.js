function loading() {
    setTimeout(tampil, 3000);
}

function tampil() {
    document.getElementById("sembunyi").style.display = "block";
}